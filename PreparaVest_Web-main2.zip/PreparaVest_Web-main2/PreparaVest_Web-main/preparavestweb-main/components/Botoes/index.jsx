import { View, Text, Pressable } from "react-native"
import { useNavigation } from '@react-navigation/native';
import { estilobotoes } from "./style";


export function Botoes(){
    
}