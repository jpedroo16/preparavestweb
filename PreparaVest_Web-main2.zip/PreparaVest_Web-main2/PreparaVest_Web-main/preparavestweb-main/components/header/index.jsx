import React, { useState, useEffect } from "react";
import { Text, View, Image, Pressable } from "react-native";
import { style } from "./style";
import { useNavigation, StackActions } from '@react-navigation/native';
import * as Font from 'expo-font';
import KollektifBold from '../../assets/fonts/Kollektif-Bold.ttf';
import Kollektif from '../../assets/fonts/Kollektif.ttf';
import { AvatarContext } from "../avatarcomp/index.jsx";
import AsyncStorage from '@react-native-async-storage/async-storage';
import GetImage from "./avatarImages.jsx";

export default function Cabecalho() {
  const navigation = useNavigation();
  const [fontsLoaded, setFontsLoaded] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState('false');
  const [email, setEmail] = useState('');
  const [id, setId] = useState('')
  const [avatarId, setAvatarId] = useState(require('../../assets/avatares/0.png'))

  // Para armazenar o estado de hover
  const [hoveredItem, setHoveredItem] = useState(null);

  useEffect(() => {
    async function loadFonts() {
      await Font.loadAsync({
        KollektifBold: KollektifBold,
        Kollektif: Kollektif,
      });
      setFontsLoaded(true);
    }

    async function loadStorage() {
      const teste = await AsyncStorage.getItem('verificaLogin')
      const email = await AsyncStorage.getItem('email')
      const id = await AsyncStorage.getItem('id')
      const avatarId = await AsyncStorage.getItem('avatarId')

      if (teste && email && id && avatarId) {
        setEmail(email)
        setId(id)
        setIsAuthenticated(teste)
        const avatar = GetImage(`${avatarId}.png`)
        setAvatarId(avatar)
      }
    }

    loadFonts()
    loadStorage()
  }, []);

  if (!fontsLoaded) {
    return (
      <View>
        <Text>Loading...</Text>
      </View>
    );
  }

  const handleMouseEnter = (item) => {
    setHoveredItem(item);
  };

  const handleMouseLeave = () => {
    setHoveredItem(null);
  };

  return (
    <View style={style.cabecalho}>
      <Image style={style.ImagemLogo} source={require('../../assets/Professores/logopreparavest.jpeg')} />

      <View style={style.subtitulo}>
        <Pressable 
          onPress={() => navigation.dispatch(StackActions.replace("Home"))}
          onMouseEnter={() => handleMouseEnter("home")}
          onMouseLeave={handleMouseLeave}
        >
          <Text style={[{ fontSize: 22,  fontFamily: "Montserrat",}, hoveredItem === "home" && style.hoveredText]}>Home</Text>
        </Pressable>

        <Pressable 
          onPress={() => navigation.dispatch(StackActions.replace("Pagina Enem"))}
          onMouseEnter={() => handleMouseEnter("provas")}
          onMouseLeave={handleMouseLeave}
        >
          <Text style={[{ fontSize: 22,  fontFamily: "Montserrat", }, hoveredItem === "provas" && style.hoveredText]}>Provas</Text>
        </Pressable>

        <Pressable 
          onPress={() => navigation.dispatch(StackActions.replace("Informacoes"))}
          onMouseEnter={() => handleMouseEnter("informacoes")}
          onMouseLeave={handleMouseLeave}
        >
          <Text style={[{ fontSize: 22,  fontFamily: "Montserrat" }, hoveredItem === "informacoes" && style.hoveredText]}>Informações Gerais</Text>
        </Pressable>

        <Pressable 
          onPress={() => navigation.dispatch(StackActions.replace("Conteudo relevante"))}
          onMouseEnter={() => handleMouseEnter("conteudo")}
          onMouseLeave={handleMouseLeave}
        >
          <Text style={[{ fontSize: 22,  fontFamily: "Montserrat" }, hoveredItem === "conteudo" && style.hoveredText]}>Conteúdo Relevante</Text>
        </Pressable>

        <Pressable 
          onPress={() => navigation.dispatch(StackActions.replace("Dicas"))}
          onMouseEnter={() => handleMouseEnter("dicas")}
          onMouseLeave={handleMouseLeave}
        >
          <Text style={[{ fontSize: 22,  fontFamily: "Montserrat" }, hoveredItem === "dicas" && style.hoveredText]}>Dicas de Estudos</Text>
        </Pressable>

        <Pressable 
          onPress={() => navigation.dispatch(StackActions.replace("Estatisticas"))}
          onMouseEnter={() => handleMouseEnter("estatisticas")}
          onMouseLeave={handleMouseLeave}
        >
          <Text style={[{ fontSize: 22,  fontFamily: "Montserrat" }, hoveredItem === "estatisticas" && style.hoveredText]}>Estatísticas</Text>
        </Pressable>
      </View>

      {/* Ícone do avatar que abre o modal de perfil */}
      {isAuthenticated == 'true' ? 
        <Pressable onPress={() => navigation.navigate("Profile")}>
          <Image source={avatarId} style={style.avatarIcon} />
        </Pressable>
        : <Pressable onPress={() => navigation.push('Login')}>Entrar</Pressable>}
    </View>
  );
}
