import React, { useState, useEffect } from "react";
import { Text, View, Image, Modal, Pressable, Alert } from "react-native";
import { style } from "./style";
import { StackActions, useNavigation } from '@react-navigation/native';
import * as Font from 'expo-font';
import KollektifBold from '../../assets/fonts/Kollektif-Bold.ttf';
import Kollektif from '../../assets/fonts/Kollektif.ttf';
import { AvatarContext } from "../../components/avatarcomp";
import AvatarSelection from "../../screens/avatar";
import AsyncStorage from '@react-native-async-storage/async-storage';
import GetImage from "../../components/header/avatarImages";


export default function Cabecalho() {
  const navigation = useNavigation();
  const [fontsLoaded, setFontsLoaded] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);
  const [modalVisible1, setModalVisible1] = useState(false); // Adicionando estado para modal de avatar
  const [email, setEmail] = useState('');
  const [id, setId] = useState('')
  const [avatarId, setAvatarId] = useState(require('../../assets/avatares/0.png'))

  // Carregamento de fontes
  useEffect(() => {
    async function loadFonts() {
      await Font.loadAsync({
        KollektifBold: KollektifBold,
        Kollektif: Kollektif,
      });
      setFontsLoaded(true);
    }

    async function loadStorage(){
      const email = await AsyncStorage.getItem('email')
      const id = await AsyncStorage.getItem('id')
      const avatarId = await AsyncStorage.getItem('avatarId')
      
      if(email && id && avatarId){
        setEmail(email)
        setId(id)
        const avatar = GetImage(`${avatarId}.png`)
        setAvatarId(avatar)
      }
    }
  
    loadFonts()
    loadStorage()
  }, []);

  if (!fontsLoaded) {
    return <View><Text>Loading...</Text></View>;
  }

  async function deslogar(){
    await AsyncStorage.setItem('verificaLogin', 'false');
    navigation.dispatch(StackActions.replace("Home"));
    alert('deslogado');
  }


  return (
    <View style={style.cabecalho}>

        {/* Modal de perfil */}
          
          <View style={style.perfilmodal}>
            <View style={style.modal}>
              <Text style={style.titulomodal}>Perfil</Text>
              <Pressable onPress={() => setModalVisible(true)}>
                <Image source={avatarId} style={style.imagemavatar} />
                <Text>Email: {email}</Text>
              
                
                </Pressable>
              <Pressable onPress={() => setModalVisible1(true)} style={style.botal}>
                <Text>Alterar foto</Text>
              </Pressable>

              {/* Modal para alterar avatar */}
              <Modal
                animationType="slide"
                transparent={true}
                visible={modalVisible1}
                onRequestClose={() => {
                  Alert.alert("Modal has been closed.");
                  setModalVisible1(!modalVisible1);
                  
                }}
              >
                <View style={style.avatarmodal}>
                  <AvatarSelection />
                  <Pressable onPress={() => navigation.goBack()}>
                    <Text style={style.titulomodal1}>Voltar a página anterior</Text>
                  </Pressable>
                </View>
              </Modal>

              <Pressable 
               onPress={deslogar}
              style={style.botal}>
                <Text>Sair da conta</Text>
              </Pressable>

              <Pressable onPress={() => navigation.goBack()}>
                <Text style={style.titulomodal1}>Voltar à página anterior</Text>
              </Pressable>        
            </View>
          </View>
    </View>
  );
}
